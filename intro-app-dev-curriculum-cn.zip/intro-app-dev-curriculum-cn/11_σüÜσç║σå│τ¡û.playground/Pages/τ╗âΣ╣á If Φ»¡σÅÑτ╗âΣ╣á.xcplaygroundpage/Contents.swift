/*:
 ## 练习：If 语句练习
 
 通过以代码的形式重写以下注释来掌握 if 语句。
*/
let a = 20
let b = 30
let c = 20

// If a is equal to c, print "a and c are the same"



// If a is less than b, print "b is ahead of a"



// If b is greater than a, print "a is not winning against b"



// If a is less than or equal to c, print "a is either losing to or tied with c"



//: - callout(Exercise): (练习):\
//: 在上述每个注释后添加代码，以遵循指示。（对于大于和小于运算符，请记住饥饿的大嘴规则）。
//:
//: [上一页](@previous)  |  第 11 页，共 13 页  |  [下一页：练习：Else 练习](@next)
