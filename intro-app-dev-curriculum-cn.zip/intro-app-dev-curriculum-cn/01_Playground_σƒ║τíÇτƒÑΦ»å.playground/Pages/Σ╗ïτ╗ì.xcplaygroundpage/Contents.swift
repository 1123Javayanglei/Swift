//: ## Playground 基础知识
//: 欢迎初次使用 playground！在本课程中，你将使用 playground 来学习编程的基础知识。我们首先来快速浏览一下，并稍微编写一些代码。
//:
//: 开始之前，你看到下面带有动画效果的圆点了吗？
//: 如果没有，请前往顶部菜单栏并选择“Editor”>“Show Rendered Markup”。
//:
//: ![带有动画效果的点](swiftloading.gif)
//:
//: 如果能看到，就可以开始了。
//:
//:第 1 页，共 7 页  |  [下一页：什么是 Playground？](@next)
