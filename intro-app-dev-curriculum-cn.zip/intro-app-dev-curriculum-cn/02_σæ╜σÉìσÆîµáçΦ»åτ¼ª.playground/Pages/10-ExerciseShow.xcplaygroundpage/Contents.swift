//: ## 练习：举行表演
//: 你朋友的宠物秀已经结束。在你的帮助下，这场秀大获成功。现在，你的朋友要举行一场音乐会。门票售价为每张 10 美元。场地费是 50 美元。制作演出海报的成本为 40 美元。帮你的朋友算算演出会赚钱还是会赔钱。
// Number Of Tickets
150

// Ticket Price
10

// Room Rental Fee
50

// Poster Cost
40

// Total Ticket Value
150 * 10

// Total Expenses
1000 + 40

// Total Income Of Show
(150 * 10) - (1000 + 40)
//: - callout(Exercise): (练习):  
//:以上述代码作为参考，使用 let 语句定义常量来更好地解决你朋友的问题。\
//:在下面添加代码。为了帮助你开始，已经定义了常量 `numberOfTickets`。 
let numberOfTickets = 150

//:
//:[上一页](@previous)  |  第 10 页，共 14 页  |  [下一页：练习：彩票](@next)
