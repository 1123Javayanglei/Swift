/*:
 ## 练习：制作购物清单

 下面的常量代表你要添加到购物清单中的一些事物：
*/
let eggs = "鸡蛋"
let milk = "牛奶"
let cheese = "奶酪"
let bread = "面包"
let rice = "大米"
let newLine = "\n"
//: - callout(Exercise):(练习): \
//:创建字符串变量，其初始值为 `""`。将上述每个常量项添加到列表，一次添加一个。在每项之间添加 `newLine`。记住，使用 `+` 运算符可以连接两个字符串。






//: [上一页](@previous)  |  第 12 页，共 13 页  |  [下一页：练习：501](@next)
