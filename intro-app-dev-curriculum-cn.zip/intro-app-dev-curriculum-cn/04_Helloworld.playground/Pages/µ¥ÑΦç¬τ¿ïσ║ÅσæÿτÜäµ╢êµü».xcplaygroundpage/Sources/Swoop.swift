

private let swiftBird = " |                            -                   \n |                            \.ds-                \n |              :\.             `mMh-              \n |         -+\.   /y:            :MMMy`            \n |         `sd/` \.dd/           hMMMN:           \n |            -dNy- +MNs\.        +MMMMM/          \n |              +NMmo:hMMh/`     /MMMMMM\.         \n |              `oNMMdyNMMNy:   oMMMMMMh         \n |                 `oNMMMMMMMMNs:mMMMMMMM         \n |                  `oNMMMMMMMMMMMMMMMMM`        \n |    `                +mMMMMMMMMMMMMMMN         \n |      +y/\.              :dMMMMMMMMMMMMy         \n |       \.hMNhs+/:----:/oydMMMMMMMMMMMMMMh`       \n |         -yMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh       \n |          `+hMMMMMMMMMMMMMMMMMMMMdhhdNMM/      \n |              `:oymNMMMMMMMMMNho-      :hs      \n |                    `\.-:::-\.`            `      \n |"


private func calculatedAnswer() -> Int {
    print("嘿，这堆编程材料绝对够你啃上一阵子的！\n\n")
    print(swiftBird)
    print("\n(出击)")
    return 42
}

public let theAnswer = calculatedAnswer()
