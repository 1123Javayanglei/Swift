public func rowTheBoat() {
    print("划呀划，划小船")
    print("沿着溪流缓缓行")
}
public func merrilyDream() {
    print("多轻松，多高兴")
    print("人生如梦不愿醒")
}
public func crocodileScream() {
    print("如果看见了鳄鱼")
    print("不要忘记大声叫")
}
public func repetitiveTheme() {
    print("这首歌谣有很多重复的部分")
    print("你能找出主旋律吗？")
}
public func breatheBetweenVerses() {
    print("        ~        ")
}
public func verseOne() {
    rowTheBoat()
    merrilyDream()
}
public func verseTwo() {
    rowTheBoat()
    crocodileScream()
}
public func verseThree() {
    rowTheBoat()
    repetitiveTheme()
}

